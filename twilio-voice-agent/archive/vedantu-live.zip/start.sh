source venv/bin/activate && uvicorn app:app --reload



./venv/bin/python -m uvicorn app:app --reload
# Visit http://127.0.0.1:8000/dashboard
# Go to "All Calls" tab
# Click any phone icon to see the beautiful call UI